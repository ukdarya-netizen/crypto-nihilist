/**
 * Signal snapshots (as AltBullet): one immutable row per signal with every
 * metric at signal time — technical (candles) and derivatives/flow from
 * CoinGlass (OI, taker, CVD, funding, liquidations, long/short) — plus the
 * market at close, and a trajectory: the same picture at fixed points of the
 * trade (TRAJECTORY below). Live signals are captured when they open; older
 * signals, closes and due trajectory points are filled by a background
 * backfill (candles from memory, CoinGlass history with end_time = that
 * moment) and marked `reconstructed`. Tables create themselves.
 */
import { pool } from "@workspace/db";
import { logger } from "../lib/logger";
import { book } from "../market/candleStore";
import {
  SNAPSHOT_VERSION, closeContext, closedAsOf, coversAsOf, marketMetrics, signalSnapshot, type Metrics, type SignalLike,
} from "../engine/metrics";
import { derivativeMetrics } from "../market/derivatives";
import { vsaMetrics } from "../market/vsa";
import { FLOW_VERSION, entryFlowMetrics, fetchFlowSeries, pointFlowMetrics, postEntryMetrics, type FlowSignal } from "../market/flow";

import { postBreakevenTrajectoryPoints, trajectoryPoints } from "../engine/trajectory";
export { trajectoryPoints };

type DueTrajectoryPoint<T> = { row: { id: number }; at: number; value: T };

/** Keep recent points responsive without letting them consume the history budget. */
export function selectTrajectoryDue<T>(
  due: DueTrajectoryPoint<T>[],
  limit: number,
  now: number,
): DueTrajectoryPoint<T>[] {
  if (limit <= 0 || due.length === 0) return [];
  const live = (d: DueTrajectoryPoint<T>) => now - d.at < 30 * 60_000;
  const liveDue = due.filter(live).sort((a, b) => b.at - a.at);
  const history = due.filter((d) => !live(d)).sort((a, b) => a.row.id - b.row.id || a.at - b.at);
  const historyReserve = history.length ? Math.min(history.length, Math.ceil(limit / 2)) : 0;
  const liveCount = Math.min(liveDue.length, limit - historyReserve);
  const historyCount = Math.min(history.length, limit - liveCount);
  const selected = [...liveDue.slice(0, liveCount), ...history.slice(0, historyCount)];
  if (selected.length < limit) {
    selected.push(...liveDue.slice(liveCount, liveCount + limit - selected.length));
  }
  return selected;
}

const BTC = "BTC-USDT";
let ensured: Promise<void> | null = null;

export function ensureSnapshotTable(): Promise<void> {
  ensured ??= pool.query(`
    CREATE TABLE IF NOT EXISTS nh_signal_snapshots (
      signal_id integer PRIMARY KEY,
      version text NOT NULL,
      status text NOT NULL DEFAULT 'ready',
      reconstructed boolean NOT NULL DEFAULT false,
      metrics jsonb,
      captured_at timestamptz NOT NULL DEFAULT now(),
      close_context jsonb,
      close_reconstructed boolean,
      close_captured_at timestamptz
    );
    ALTER TABLE nh_signal_snapshots ADD COLUMN IF NOT EXISTS deriv_at timestamptz;
    ALTER TABLE nh_signal_snapshots ADD COLUMN IF NOT EXISTS close_deriv_at timestamptz;
    CREATE TABLE IF NOT EXISTS nh_signal_trajectory (
      signal_id integer NOT NULL,
      label text NOT NULL,
      at timestamptz NOT NULL,
      elapsed_ms bigint NOT NULL,
      price double precision,
      pct_from_entry double precision,
      metrics jsonb,
      reconstructed boolean NOT NULL DEFAULT false,
      captured_at timestamptz NOT NULL DEFAULT now(),
      PRIMARY KEY (signal_id, label)
    )`).then(() => undefined).catch((err) => { ensured = null; throw err; });
  return ensured;
}

function serializeValue(value: unknown, seen: WeakSet<object>): unknown {
  if (typeof value === "bigint") return value.toString();
  if (typeof value === "symbol" || typeof value === "function") return String(value);
  if (value === null || typeof value !== "object") return value;
  if (value instanceof Error) return serializeThrown(value, seen);
  if (seen.has(value)) return "[Circular]";
  seen.add(value);
  try {
    if (Array.isArray(value)) return value.map((item) => serializeValue(item, seen));
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, serializeValue(item, seen)]));
  } finally {
    seen.delete(value);
  }
}

function serializeThrown(err: unknown, seen = new WeakSet<object>()): unknown {
  if (err === null || (typeof err !== "object" && typeof err !== "function")) {
    return { type: typeof err, message: String(err), value: serializeValue(err, seen) };
  }
  if (seen.has(err)) return "[Circular]";
  seen.add(err);
  try {
    const fields: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(err)) fields[key] = serializeValue(value, seen);
    if (err instanceof Error) {
      fields.type = err.name;
      fields.message = err.message;
      if (err.stack) fields.stack = err.stack;
      if (err.cause !== undefined) fields.cause = serializeValue(err.cause, seen);
    } else {
      const type = Object.getPrototypeOf(err)?.constructor?.name;
      if (type && type !== "Object") fields.type = type;
      if (fields.message === undefined) fields.message = String(err);
    }
    return fields;
  } finally {
    seen.delete(err);
  }
}

export type SnapshotBackfillStage = "entry" | "close" | "derivs" | "vsa" | "trajectory" | "flow";

export const SNAPSHOT_BACKFILL_STALE_AFTER_MS = 30 * 60_000;

export type SnapshotBackfillDiagnostics = {
  monitoringSince: number | null;
  lastStartedAt: number | null;
  lastSuccessfulAt: number | null;
  lastFailedAt: number | null;
  running: boolean;
  ageMs: number | null;
  staleAfterMs: number;
  overdue: boolean;
};

type SnapshotBackfillWarningTarget = {
  warn?: (fields: Record<string, unknown>, message: string) => void;
};

/** Tracks backfill completion health and rate-limits repeated overdue warnings. */
export class SnapshotBackfillMonitor {
  private monitoringSince: number | null = null;
  private lastStartedAt: number | null = null;
  private lastSuccessfulAt: number | null = null;
  private lastFailedAt: number | null = null;
  private lastWarningAt: number | null = null;
  private running = false;

  constructor(private readonly staleAfterMs = SNAPSHOT_BACKFILL_STALE_AFTER_MS) {}

  startMonitoring(now: number, lastSuccessfulAt: number | null = null): void {
    this.monitoringSince ??= now;
    this.restoreLastSuccessfulAt(lastSuccessfulAt);
  }

  restoreLastSuccessfulAt(at: number | null): void {
    if (at === null || !Number.isFinite(at) || at < 0) return;
    if (this.lastSuccessfulAt === null || at > this.lastSuccessfulAt) this.lastSuccessfulAt = at;
  }

  markStarted(now: number): void {
    this.monitoringSince ??= now;
    this.lastStartedAt = now;
    this.running = true;
  }

  markSucceeded(now: number): void {
    this.monitoringSince ??= now;
    this.lastSuccessfulAt = now;
    this.running = false;
    this.lastWarningAt = null;
  }

  markFailed(now: number): void {
    this.lastFailedAt = now;
    this.running = false;
  }

  status(now: number): SnapshotBackfillDiagnostics {
    const baseline = this.lastSuccessfulAt ?? this.monitoringSince;
    const ageMs = baseline === null ? null : Math.max(0, now - baseline);
    return {
      monitoringSince: this.monitoringSince,
      lastStartedAt: this.lastStartedAt,
      lastSuccessfulAt: this.lastSuccessfulAt,
      lastFailedAt: this.lastFailedAt,
      running: this.running,
      ageMs,
      staleAfterMs: this.staleAfterMs,
      overdue: ageMs !== null && ageMs >= this.staleAfterMs,
    };
  }

  logOverdueIfNeeded(now: number, target: SnapshotBackfillWarningTarget): boolean {
    const status = this.status(now);
    if (!status.overdue) return false;
    if (this.lastWarningAt !== null && now - this.lastWarningAt < this.staleAfterMs) return false;
    this.lastWarningAt = now;
    target.warn?.({
      lastSuccessfulAt: status.lastSuccessfulAt,
      lastStartedAt: status.lastStartedAt,
      lastFailedAt: status.lastFailedAt,
      ageMs: status.ageMs,
      staleAfterMs: status.staleAfterMs,
      running: status.running,
    }, "nihilist: snapshot backfill overdue");
    return true;
  }
}

export class SnapshotBackfillStageError extends Error {
  constructor(
    readonly stage: SnapshotBackfillStage,
    readonly originalError: unknown,
  ) {
    super(`snapshot backfill ${stage} stage failed`, { cause: originalError });
    this.name = "SnapshotBackfillStageError";
  }
}

export async function runSnapshotBackfillStage<T>(
  stage: SnapshotBackfillStage,
  action: () => Promise<T>,
): Promise<T> {
  try {
    return await action();
  } catch (err) {
    throw new SnapshotBackfillStageError(stage, err);
  }
}

export function snapshotBackfillErrorFields(err: unknown): { stage?: SnapshotBackfillStage; err: unknown } {
  if (err instanceof SnapshotBackfillStageError) {
    return { stage: err.stage, err: serializeThrown(err.originalError) };
  }
  return { err: serializeThrown(err) };
}

type SnapshotBackfillLog = {
  error: (fields: Record<string, unknown>, message: string) => void;
  info: (fields: Record<string, unknown>, message: string) => void;
  warn?: (fields: Record<string, unknown>, message: string) => void;
};

export function logSnapshotBackfillFailure(
  err: unknown,
  message = "nihilist: snapshot backfill failed",
  target: SnapshotBackfillLog = logger,
): void {
  target.error(snapshotBackfillErrorFields(err), message);
}

export async function runSnapshotBackfillRows<T>(
  stage: SnapshotBackfillStage,
  rows: T[],
  signalId: (row: T) => number,
  action: (row: T) => Promise<void>,
  target: SnapshotBackfillLog = logger,
): Promise<void> {
  for (const row of rows) {
    const id = signalId(row);
    try {
      await action(row);
    } catch (err) {
      target.error(
        { stage, signalId: id, err: serializeThrown(err) },
        "nihilist: snapshot backfill record failed",
      );
    }
  }
}

export function logSnapshotBackfillResult(
  result: { entries: number; closes: number; unavailable: number; derivs: number; trajectory: number },
  target: SnapshotBackfillLog = logger,
): void {
  if (result.entries || result.closes || result.unavailable || result.derivs || result.trajectory) {
    target.info(result, "nihilist: snapshot backfill");
  }
}

type SnapshotCaptureLog = {
  warn: (fields: Record<string, unknown>, message: string) => void;
};

export async function runLiveSnapshotCapture(
  signalId: number,
  capture: () => Promise<void>,
  target: SnapshotCaptureLog = logger,
): Promise<void> {
  try {
    await capture();
  } catch (err) {
    target.warn(
      { signalId, err: serializeThrown(err) },
      "nihilist: live snapshot capture failed (backfill will retry)",
    );
  }
}

type SignalRow = {
  id: number; symbol: string; side: "long" | "short"; htf: string; ltf: string; entry: number; stop: number; tp1: number;
  risk_pct: number; rr1: number; block_top: number; block_bottom: number; block_scope: string; targets_source: string;
  opened_at: Date; closed_at: Date | null; details: Record<string, unknown>;
};

export function signalLikeFromRow(row: SignalRow): SignalLike {
  const d = row.details ?? {};
  const n = (v: unknown) => (v === null || v === undefined || !Number.isFinite(Number(v)) ? null : Number(v));
  return {
    symbol: row.symbol, side: row.side, htf: row.htf, ltf: row.ltf,
    entry: Number(row.entry), stop: Number(row.stop), tp1: Number(row.tp1),
    riskPct: Number(row.risk_pct), rr1: Number(row.rr1),
    blockTop: Number(row.block_top), blockBottom: Number(row.block_bottom), blockScope: row.block_scope,
    blockTime: n(d.blockTime), blockCreatedAt: n(d.blockCreatedAt),
    firstTouchAt: n(d.firstTouchAt), lastTouchAt: n(d.lastTouchAt),
    htfSwingTrend: n(d.htfSwingTrend), htfInternalTrend: n(d.htfInternalTrend), ltfAtr: n(d.ltfAtr),
    targetsSource: row.targets_source, signalAt: new Date(row.opened_at).getTime(),
    ob: d.ob && typeof d.ob === "object" ? d.ob as SignalLike["ob"] : null,
    confluenceSetups: Array.isArray(d.confluenceSetups) ? d.confluenceSetups as string[] : null,
    chochBar: d.chochBar && typeof d.chochBar === "object" ? d.chochBar as SignalLike["chochBar"] : null,
  };
}

async function write(signalId: number, status: string, reconstructed: boolean, metrics: Metrics | null): Promise<void> {
  await ensureSnapshotTable();
  await pool.query(
    `INSERT INTO nh_signal_snapshots (signal_id, version, status, reconstructed, metrics)
     VALUES ($1, $2, $3, $4, $5) ON CONFLICT (signal_id) DO NOTHING`,
    [signalId, SNAPSHOT_VERSION, status, reconstructed, metrics ? JSON.stringify(metrics) : null],
  );
}

/** Live capture at signal time. Never throws: a snapshot must not block a signal. */
export async function captureSnapshot(signalId: number, sig: SignalLike): Promise<void> {
  await runLiveSnapshotCapture(signalId, async () => {
    const btc = sig.symbol === BTC ? null : book(BTC);
    await write(signalId, "ready", false, signalSnapshot(sig, book(sig.symbol), btc));
    // CoinGlass reads take a few seconds: never hold up the signal for them.
    void addDerivatives(signalId, sig.symbol, sig.signalAt, "entry").catch(() => undefined);
    void addVsa(signalId, sig).catch(() => undefined);
  });
}

/**
 * VSA (volume from BingX) merged into the entry snapshot; vsa_at marks it done
 * (also when BingX had no bars, so it is not retried forever).
 */
async function addVsa(signalId: number, sig: SignalLike): Promise<void> {
  const m = await vsaMetrics({ symbol: sig.symbol, side: sig.side, ltf: sig.ltf, signalAt: sig.signalAt, firstTouchAt: sig.firstTouchAt });
  await pool.query(
    `UPDATE nh_signal_snapshots SET metrics = coalesce(metrics, '{}'::jsonb) || $2::jsonb WHERE signal_id = $1`,
    [signalId, JSON.stringify({ ...m, vsa_checked: true })],
  );
}

/** Merges CoinGlass metrics at `at` into the entry snapshot or the close context. */
async function addDerivatives(signalId: number, symbol: string, at: number, which: "entry" | "close"): Promise<void> {
  const d = await derivativeMetrics(symbol, at);
  const col = which === "entry" ? "metrics" : "close_context";
  const mark = which === "entry" ? "deriv_at" : "close_deriv_at";
  await pool.query(
    `UPDATE nh_signal_snapshots SET ${col} = coalesce(${col}, '{}'::jsonb) || $2::jsonb, ${mark} = now()
     WHERE signal_id = $1`,
    [signalId, JSON.stringify(d)],
  );
}

/** Price at a moment: close of the last 30m bar closed by then. */
function priceAt(symbol: string, at: number): number | null {
  const s = closedAsOf(book(symbol)["30m"], "30m", at);
  return s.length ? s[s.length - 1].c : null;
}

/** One backfill pass: missing entry snapshots, then missing close contexts. */
export async function backfillSnapshots(limit = 300): Promise<{ entries: number; closes: number; unavailable: number; derivs: number; trajectory: number }> {
  let entries = 0; let closes = 0; let unavailable = 0;
  await runSnapshotBackfillStage("entry", async () => {
    await ensureSnapshotTable();
    const { rows } = await pool.query<SignalRow>(
      `SELECT s.id, s.symbol, s.side, s.htf, s.ltf, s.entry, s.stop, s.tp1, s.risk_pct, s.rr1, s.block_top, s.block_bottom,
              s.block_scope, s.targets_source, s.opened_at, s.closed_at, s.details
       FROM nh_signals s LEFT JOIN nh_signal_snapshots n ON n.signal_id = s.id
       WHERE n.signal_id IS NULL ORDER BY s.id DESC LIMIT $1`, [limit],
    );
    await runSnapshotBackfillRows("entry", rows, (row) => row.id, async (row) => {
      const sig = signalLikeFromRow(row);
      const coin = book(row.symbol);
      if (coversAsOf(coin, sig.signalAt)) {
        const btc = row.symbol === BTC ? null : book(BTC);
        await write(row.id, "ready", true, signalSnapshot(sig, coin, btc && coversAsOf(btc, sig.signalAt) ? btc : null));
        entries += 1;
      } else if (coin["30m"].length >= 200 && coin["30m"][0].t > sig.signalAt) {
        // History is loaded but starts after the signal: it can never be rebuilt.
        await write(row.id, "unavailable", true, null);
        unavailable += 1;
      }
    });
  });
  await runSnapshotBackfillStage("close", async () => {
    const closed = await pool.query<SignalRow & { reconstructed_entry: boolean }>(
      `SELECT s.id, s.symbol, s.closed_at FROM nh_signals s JOIN nh_signal_snapshots n ON n.signal_id = s.id
       WHERE s.status = 'closed' AND s.closed_at IS NOT NULL AND n.close_context IS NULL
       ORDER BY s.id DESC LIMIT $1`, [limit],
    );
    await runSnapshotBackfillRows("close", closed.rows, (row) => row.id, async (row) => {
      const at = new Date(row.closed_at as Date).getTime();
      const coin = book(row.symbol);
      if (!coversAsOf(coin, at)) return;
      const btc = row.symbol === BTC ? null : book(BTC);
      const late = Date.now() - at > 60 * 60_000;
      await pool.query(
        `UPDATE nh_signal_snapshots SET close_context = $2, close_reconstructed = $3, close_captured_at = now()
         WHERE signal_id = $1 AND close_context IS NULL`,
        [row.id, JSON.stringify(closeContext(coin, btc && coversAsOf(btc, at) ? btc : null, at)), late],
      );
      closes += 1;
    });
  });

  // Derivatives for entry snapshots and closes (CoinGlass budget: bounded per pass).
  let derivs = 0;
  await runSnapshotBackfillStage("derivs", async () => {
    const needDeriv = await pool.query<{ signal_id: number; symbol: string; opened_at: Date; closed_at: Date | null; entry_missing: boolean }>(
      `SELECT n.signal_id, s.symbol, s.opened_at, s.closed_at, (n.deriv_at IS NULL) AS entry_missing
       FROM nh_signal_snapshots n JOIN nh_signals s ON s.id = n.signal_id
       WHERE n.status = 'ready' AND (n.deriv_at IS NULL OR (n.close_context IS NOT NULL AND n.close_deriv_at IS NULL))
       ORDER BY n.signal_id DESC LIMIT 25`,
    );
    await runSnapshotBackfillRows("derivs", needDeriv.rows, (row) => row.signal_id, async (row) => {
      if (row.entry_missing) await addDerivatives(row.signal_id, row.symbol, new Date(row.opened_at).getTime(), "entry");
      else if (row.closed_at) await addDerivatives(row.signal_id, row.symbol, new Date(row.closed_at).getTime(), "close");
      derivs += 1;
    });
  });

  // VSA for signals recorded before it existed (BingX, 25 per pass).
  await runSnapshotBackfillStage("vsa", async () => {
    const { rows } = await pool.query<SignalRow>(
      `SELECT s.id, s.symbol, s.side, s.htf, s.ltf, s.entry, s.stop, s.tp1, s.risk_pct, s.rr1, s.block_top, s.block_bottom,
              s.block_scope, s.targets_source, s.opened_at, s.closed_at, s.details
       FROM nh_signal_snapshots n JOIN nh_signals s ON s.id = n.signal_id
       WHERE n.status = 'ready' AND NOT (n.metrics ? 'vsa_checked') ORDER BY s.id DESC LIMIT 25`,
    );
    await runSnapshotBackfillRows("vsa", rows, (row) => row.id, async (row) => {
      await addVsa(row.id, signalLikeFromRow(row));
      await new Promise((r) => setTimeout(r, 150));
    });
  });

  const trajectory = await runSnapshotBackfillStage("trajectory", () => backfillTrajectory(200));
  // Volume / OI / delta on every timeframe (owner 2026-11-03): entry, early post-entry and every trajectory point.
  await runSnapshotBackfillStage("flow", () => backfillFlow(8));
  return { entries, closes, unavailable, derivs, trajectory };
}

/**
 * Flow metrics (market/flow.ts) for signals that miss them: the entry
 * snapshot, the post-entry marks (+1h/+2h/+4h) and every trajectory point
 * without them. One fetch per signal covers all its moments. Newest first.
 */
export async function backfillFlow(limit: number, now = Date.now()): Promise<number> {
  const { rows } = await pool.query<SignalRow & { need_entry: boolean; need_post: boolean }>(
    `SELECT s.id, s.symbol, s.side, s.htf, s.ltf, s.opened_at, s.closed_at, s.details,
            NOT (coalesce(n.metrics, '{}'::jsonb) ? 'flow_v') AS need_entry,
            (s.opened_at < now() - interval '4 hours' AND NOT (coalesce(n.metrics, '{}'::jsonb) ? 'flow_post_v')) AS need_post
     FROM nh_signal_snapshots n JOIN nh_signals s ON s.id = n.signal_id
     WHERE n.status = 'ready' AND (
       NOT (coalesce(n.metrics, '{}'::jsonb) ? 'flow_v')
       OR (s.opened_at < now() - interval '4 hours' AND NOT (coalesce(n.metrics, '{}'::jsonb) ? 'flow_post_v'))
       OR EXISTS (SELECT 1 FROM nh_signal_trajectory t WHERE t.signal_id = s.id AND NOT (coalesce(t.metrics, '{}'::jsonb) ? 'flow_v')))
     ORDER BY s.id DESC LIMIT $1`, [limit],
  );
  let done = 0;
  await runSnapshotBackfillRows("flow", rows, (row) => row.id, async (row) => {
    const d = row.details ?? {};
    const n = (v: unknown) => (v === null || v === undefined || !Number.isFinite(Number(v)) ? null : Number(v));
    const sig: FlowSignal = {
      symbol: row.symbol, side: row.side, htf: row.htf, ltf: row.ltf, signalAt: new Date(row.opened_at).getTime(),
      firstTouchAt: n(d.firstTouchAt), blockTime: n(d.blockTime),
    };
    const s = await fetchFlowSeries(sig, now);
    const empty = !(s.bars["30m"]?.length) && !(s.oi["1h"]?.length);
    if (row.need_entry) {
      const m = empty ? { flow_v: FLOW_VERSION, flow_empty: 1 } : entryFlowMetrics(sig, s);
      await pool.query(`UPDATE nh_signal_snapshots SET metrics = coalesce(metrics, '{}'::jsonb) || $2::jsonb WHERE signal_id = $1`, [row.id, JSON.stringify(m)]);
    }
    if (row.need_post) {
      await pool.query(`UPDATE nh_signal_snapshots SET metrics = coalesce(metrics, '{}'::jsonb) || $2::jsonb WHERE signal_id = $1`,
        [row.id, JSON.stringify({ ...(empty ? {} : postEntryMetrics(sig, s, now)), flow_post_v: FLOW_VERSION })]);
    }
    const pts = await pool.query<{ label: string; at: Date }>(
      "SELECT label, at FROM nh_signal_trajectory WHERE signal_id = $1 AND NOT (coalesce(metrics, '{}'::jsonb) ? 'flow_v')", [row.id]);
    for (const p of pts.rows) {
      const m = empty ? { flow_v: FLOW_VERSION, flow_empty: 1 } : pointFlowMetrics(sig, s, new Date(p.at).getTime());
      await pool.query(`UPDATE nh_signal_trajectory SET metrics = coalesce(metrics, '{}'::jsonb) || $3::jsonb WHERE signal_id = $1 AND label = $2`,
        [row.id, p.label, JSON.stringify(m)]);
    }
    done += 1;
  });
  return done;
}

/** Due trajectory points, newest first (the live picture stays current; history fills behind). */
export async function backfillTrajectory(limit: number, now = Date.now()): Promise<number> {
  const { rows } = await pool.query<{ id: number; symbol: string; side: "long" | "short"; entry: number; opened_at: Date; closed_at: Date | null; be_at: Date | null; details: Record<string, unknown>; have: string[] | null }>(
    `SELECT s.id, s.symbol, s.side, s.entry, s.opened_at, s.closed_at, s.details,
            be.created_at AS be_at,
            (SELECT array_agg(t.label) FROM nh_signal_trajectory t WHERE t.signal_id = s.id) AS have
     FROM nh_signals s
     LEFT JOIN LATERAL (
       SELECT e.created_at FROM nh_signal_events e
       WHERE e.signal_id = s.id AND e.kind IN ('breakeven', 'tp1')
       ORDER BY e.created_at, e.id LIMIT 1
     ) be ON true
     WHERE s.opened_at > now() - interval '40 days'
        OR be.created_at > now() - interval '72 hours'
     ORDER BY s.id DESC LIMIT 400`,
  );
  const due: Array<{ row: (typeof rows)[number]; label: string; offsetMs: number; at: number }> = [];
  for (const row of rows) {
    const opened = new Date(row.opened_at).getTime();
    const end = row.closed_at ? new Date(row.closed_at).getTime() : now;
    const touch = Number(row.details?.firstTouchAt);
    const have = new Set(row.have ?? []);
    for (const p of trajectoryPoints(opened, Number.isFinite(touch) ? touch : null, end)) {
      const at = opened + p.offsetMs;
      if (at > end || at > now || have.has(p.label)) continue;
      due.push({ row, label: p.label, offsetMs: p.offsetMs, at });
    }
    if (row.be_at) {
      const beAt = new Date(row.be_at).getTime();
      const postBeEnd = Math.min(now, beAt + 72 * 60 * 60_000);
      for (const p of postBreakevenTrajectoryPoints(beAt, postBeEnd)) {
        const at = beAt + p.offsetMs;
        if (at > now || have.has(p.label)) continue;
        due.push({ row, label: p.label, offsetMs: at - opened, at });
      }
    }
  }
  // The scan's current picture stays responsive, while each pass reserves
  // capacity for older history even when new live points keep arriving.
  const picked = selectTrajectoryDue(due.map((d) => ({ ...d, value: d })), limit, now)
    .map((d) => d.value);
  let done = 0;
  await runSnapshotBackfillRows("trajectory", picked, (d) => d.row.id, async (d) => {
    if (done >= limit) return;
    const { row, at } = d;
    const coin = book(row.symbol);
    if (!coversAsOf(coin, at)) return; // candles not loaded yet / too old
    const price = priceAt(row.symbol, at);
    const dir = row.side === "long" ? 1 : -1;
    const btc = row.symbol === BTC ? null : book(BTC);
    const b = btc && coversAsOf(btc, at) ? marketMetrics(btc, at, "btc_") : null;
    const metrics = {
      ...marketMetrics(coin, at),
      ...(b ? { btc_chg1h: b.btc_chg1h, btc_chg24h: b.btc_chg24h } : {}),
      ...(await derivativeMetrics(row.symbol, at)),
    };
    await pool.query(
      `INSERT INTO nh_signal_trajectory (signal_id, label, at, elapsed_ms, price, pct_from_entry, metrics, reconstructed)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT (signal_id, label) DO NOTHING`,
      [row.id, d.label, new Date(at), d.offsetMs, price,
        price === null ? null : Math.round(((price - row.entry) / row.entry) * 100 * dir * 100) / 100,
        JSON.stringify(metrics), now - at > 15 * 60_000],
    );
    done += 1;
  });
  return done;
}

let backfillRunning = false;
let backfillScheduled = false;
const BACKFILL_LAST_SUCCESS_KEY = "snapshot_backfill:last_success_at";
const backfillMonitor = new SnapshotBackfillMonitor();

function storedTimestamp(value: unknown): number | null {
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : Number.NaN;
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
}

export function snapshotBackfillDiagnostics(now = Date.now()): SnapshotBackfillDiagnostics {
  return backfillMonitor.status(now);
}

export function startSnapshotBackfill(): void {
  if (backfillScheduled) return;
  backfillScheduled = true;
  backfillMonitor.startMonitoring(Date.now());
  const lastSuccessLoaded = pool.query<{ value: unknown }>(
    "SELECT value FROM nh_state WHERE key = $1",
    [BACKFILL_LAST_SUCCESS_KEY],
  ).then(({ rows }) => {
    backfillMonitor.restoreLastSuccessfulAt(storedTimestamp(rows[0]?.value));
  }).catch((err) => {
    logger.warn({ err }, "nihilist: snapshot backfill health state unavailable");
  });

  const run = () => {
    backfillMonitor.logOverdueIfNeeded(Date.now(), logger);
    if (backfillRunning) return;
    backfillRunning = true;
    backfillMonitor.markStarted(Date.now());
    void (async () => {
      try {
        await lastSuccessLoaded;
        const result = await backfillSnapshots();
        const completedAt = Date.now();
        backfillMonitor.markSucceeded(completedAt);
        logSnapshotBackfillResult(result);
        void pool.query(
          `INSERT INTO nh_state (key, value, updated_at) VALUES ($1, $2::jsonb, now())
           ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`,
          [BACKFILL_LAST_SUCCESS_KEY, JSON.stringify(completedAt)],
        ).catch((err) => logger.warn(
          { err, lastSuccessfulAt: completedAt },
          "nihilist: snapshot backfill completion time persistence failed",
        ));
      } catch (err) {
        backfillMonitor.markFailed(Date.now());
        logSnapshotBackfillFailure(err);
      } finally {
        backfillRunning = false;
      }
    })();
  };
  setTimeout(run, 30_000).unref?.();
  // Every 2 minutes: trajectory points are due 15 minutes after entry.
  setInterval(run, 2 * 60_000).unref?.();
}
