import assert from "node:assert/strict";
import test from "node:test";
import type { Candle } from "./candles";
import { evaluateSetups } from "./setups";
import { candlesFromCloses, path } from "./testCandles.test-helper";

const M30 = 30 * 60_000;

function aggregate(candles: Candle[], per: number): Candle[] {
  const out: Candle[] = [];
  for (let i = 0; i + per <= candles.length; i += per) {
    const part = candles.slice(i, i + per);
    out.push({
      t: part[0].t, o: part[0].o, c: part[part.length - 1].c,
      h: Math.max(...part.map((c) => c.h)), l: Math.min(...part.map((c) => c.l)),
    });
  }
  return out;
}

/** 4h: bearish leg, then bullish CHoCH leaving a bullish OB near 84; 30m: return into it and flip up. */
function scenario(bottom: number) {
  const htfShape = path([[90, 80], [100, 80], [84, 128], [104, 160]], 100);
  const ltfReturn = path([[96, 8], [98, 6], [89, 12], [90.5, 6], [bottom, 12], [97, 20], [99, 10]], 104).slice(1);
  const closes = [...htfShape, ...ltfReturn];
  const start = Date.UTC(2026, 0, 1);
  const ltf = candlesFromCloses(closes, start, M30);
  const usable = ltf.slice(0, Math.floor(ltf.length / 8) * 8);
  return { ltf: usable, htf: aggregate(usable, 8) };
}

test("long: 30m CHoCH after the price returns into a 4h bullish order block", () => {
  const { ltf, htf } = scenario(84.8);
  const { signals } = evaluateSetups({ htf: "4h", ltf: "30m", htfCandles: htf, ltfCandles: ltf, sides: ["long"] });
  assert.equal(signals.length, 1, JSON.stringify(signals));
  const s = signals[0];
  assert.equal(s.setup, "4h_30m_long");
  assert.ok(s.entry > 90.5 && s.entry < 93, `entry ${s.entry}`);
  assert.ok(s.stop < 84.8 * 0.999, `stop ${s.stop}`);
  assert.ok(s.block.bottom < 84.8 && s.block.top >= 84.8 * 0.999);
  assert.equal(s.targetsSource, "structure");
  assert.ok(s.tp1 > 103 && s.tp1 < 105, `tp1 ${s.tp1}`);
  assert.ok(s.rr1 >= 1);
});

test("no signal when the return trades through the block bottom", () => {
  const { ltf, htf } = scenario(82);
  const { signals } = evaluateSetups({ htf: "4h", ltf: "30m", htfCandles: htf, ltfCandles: ltf, sides: ["long"] });
  assert.equal(signals.length, 0);
});

test("no lookahead: nothing before the order block's 4h bar has closed", () => {
  const { ltf, htf } = scenario(84.8);
  const full = evaluateSetups({ htf: "4h", ltf: "30m", htfCandles: htf, ltfCandles: ltf, sides: ["long"] });
  const signalAt = full.signals[0].signalAt;
  // Same LTF bars, but HTF bars only up to the signal: identical result.
  const partialHtf = htf.filter((c) => c.t + 4 * 60 * 60_000 <= signalAt);
  const partial = evaluateSetups({ htf: "4h", ltf: "30m", htfCandles: partialHtf, ltfCandles: ltf.filter((c) => c.t + M30 <= signalAt), sides: ["long"] });
  assert.equal(partial.signals.length, 1);
  assert.equal(partial.signals[0].entry, full.signals[0].entry);
  assert.equal(partial.signals[0].tp1, full.signals[0].tp1);
});

test("short is the mirror image", () => {
  const { ltf, htf } = scenario(84.8);
  const mirror = (c: Candle): Candle => ({ t: c.t, o: 200 - c.o, c: 200 - c.c, h: 200 - c.l, l: 200 - c.h });
  const { signals } = evaluateSetups({ htf: "4h", ltf: "30m", htfCandles: htf.map(mirror), ltfCandles: ltf.map(mirror), sides: ["short"] });
  assert.equal(signals.length, 1);
  assert.equal(signals[0].side, "short");
  assert.ok(signals[0].stop > signals[0].entry && signals[0].tp1 < signals[0].entry);
});

test("stop sits 3% beyond the TA stop (owner rule); rr and risk follow it", () => {
  const { ltf, htf } = scenario(84.8);
  const base = { htf: "4h" as const, ltf: "30m" as const, htfCandles: htf, ltfCandles: ltf, sides: ["long" as const] };
  const ta = evaluateSetups({ ...base, options: { stopExtraPct: 0, minRr: 0 } }).signals[0];
  const live = evaluateSetups({ ...base, options: { minRr: 0 } }).signals[0];
  assert.ok(ta && live);
  assert.ok(Math.abs(live.stop - ta.stop * 0.97) < 1e-9, `${live.stop} vs ${ta.stop}`);
  assert.ok(live.riskPct > ta.riskPct && live.rr1 < ta.rr1);
});

test("order-block strength is measured on every signal and can filter weak blocks", () => {
  const { ltf, htf } = scenario(84.8);
  const base = { htf: "4h" as const, ltf: "30m" as const, htfCandles: htf, ltfCandles: ltf, sides: ["long" as const] };
  const s = evaluateSetups(base).signals[0];
  assert.ok(s.ob.displacementAtr !== null && s.ob.displacementAtr > 0, JSON.stringify(s.ob));
  assert.ok(s.ob.breakBars !== null && s.ob.breakBars >= 1);
  assert.ok(s.ob.penetrationPct !== null && s.ob.penetrationPct >= 0);
  const strict = evaluateSetups({ ...base, options: { minObDisplacementAtr: s.ob.displacementAtr! + 1 } });
  assert.equal(strict.signals.length, 0);
  assert.equal(strict.rejections[0]?.reason, "ob_too_weak");
});

test("SMC conditions: measured on every signal, the same for the mirrored short, no lookahead", () => {
  const { ltf, htf } = scenario(84.8);
  const long = evaluateSetups({ htf: "4h", ltf: "30m", htfCandles: htf, ltfCandles: ltf, sides: ["long"] }).signals[0]!;
  const mirror = (c: Candle): Candle => ({ t: c.t, o: 200 - c.o, c: 200 - c.c, h: 200 - c.l, l: 200 - c.h });
  const short = evaluateSetups({ htf: "4h", ltf: "30m", htfCandles: htf.map(mirror), ltfCandles: ltf.map(mirror), sides: ["short"] }).signals[0]!;
  assert.deepEqual(short.smc, long.smc);
  // The scenario: bullish CHoCH (swing trend up), a fresh block, a fast impulse leaving a gap.
  assert.equal(long.smc.fresh, true);
  assert.equal(long.smc.fvg, true);
  // The short test series has no 50-bar swing yet: no range, the zone is unknown.
  assert.equal(long.smc.discount, null);
  const partial = evaluateSetups({
    htf: "4h", ltf: "30m", sides: ["long"],
    htfCandles: htf.filter((c) => c.t + 4 * 60 * 60_000 <= long.signalAt), ltfCandles: ltf.filter((c) => c.t + M30 <= long.signalAt),
  }).signals[0]!;
  assert.deepEqual(partial.smc, long.smc);
});

test("SMC: a block price already returned to before the LTF series starts is not fresh", () => {
  const { ltf, htf } = scenario(84.8);
  const s = evaluateSetups({ htf: "4h", ltf: "30m", htfCandles: htf, ltfCandles: ltf, sides: ["long"] }).signals[0]!;
  const brIdx = htf.findIndex((c) => c.t === s.block.createdAt);
  const h4 = 4 * 60 * 60_000;
  // LTF series starting two 4h bars after the break; the first closed 4h bar after the break dips into the block.
  const start = htf[brIdx + 2]!.t;
  const later = ltf.filter((c) => c.t >= start);
  const dipped = htf.map((c, i) => (i === brIdx + 1 ? { ...c, l: s.block.top - 0.01 } : c));
  const clean = evaluateSetups({ htf: "4h", ltf: "30m", htfCandles: htf, ltfCandles: later, sides: ["long"] }).signals[0];
  const dirty = evaluateSetups({ htf: "4h", ltf: "30m", htfCandles: dipped, ltfCandles: later, sides: ["long"] }).signals[0];
  assert.ok(clean && dirty, "signal in both");
  assert.ok(htf[brIdx + 1]!.t + h4 <= start);
  assert.equal(clean.smc.fresh, true);
  assert.equal(dirty.smc.fresh, false);
});
