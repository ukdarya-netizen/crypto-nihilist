import assert from "node:assert/strict";
import test from "node:test";
import { setScanBusy } from "./coinglass";
import { cgBase, derivativeMetrics } from "./derivatives";

const H = 3_600_000;
const asOf = Date.UTC(2026, 9, 26, 12, 0);
const bars = (n: number, f: (i: number) => Record<string, number>) =>
  Array.from({ length: n }, (_, i) => ({ time: asOf - (n - i) * H, ...f(i) }));

test("CoinGlass metrics at a moment: OI and long/short only", async () => {
  process.env.NIHILIST_COINGLASS_API_KEY = "test";
  const seen: string[] = [];
  const original = globalThis.fetch;
  globalThis.fetch = (async (input: string | URL) => {
    const url = new URL(String(input));
    seen.push(`${url.pathname}?end_time=${url.searchParams.get("end_time")}&symbol=${url.searchParams.get("symbol")}`);
    const path = url.pathname;
    const data =
      path.endsWith("open-interest/aggregated-history") ? bars(30, (i) => ({ close: 1000 + i * 10 })) :
      path.endsWith("aggregated-taker-buy-sell-volume/history") ? bars(30, () => ({ aggregated_buy_volume_usd: 60, aggregated_sell_volume_usd: 40 })) :
      path.endsWith("aggregated-cvd/history") ? bars(30, (i) => ({ agg_taker_buy_vol: 5, agg_taker_sell_vol: 5, cum_vol_delta: i * 2 })) :
      path.endsWith("liquidation/aggregated-history") ? bars(30, () => ({ aggregated_long_liquidation_usd: 10, aggregated_short_liquidation_usd: 1 })) :
      path.endsWith("global-long-short-account-ratio/history") ? bars(6, (i) => ({ global_account_long_percent: 60 + i })) :
      bars(4, () => ({ close: 0.01 }));
    return new Response(JSON.stringify({ code: "0", data }), { status: 200 });
  }) as typeof fetch;
  try {
    const m = await derivativeMetrics("JCT-USDT", asOf);
    assert.ok(seen.every((s) => s.includes(`end_time=${asOf}`) && s.includes("symbol=JCT")), seen.join("\n"));
    assert.equal(m.d_oi_usd, 1290);
    assert.equal(m.d_oi_chg1h, Math.round((10 / 1280) * 10000) / 100);
    assert.equal(m.d_fut_taker_net_4h, undefined);
    assert.equal(m.d_spot_cvd_chg4h, undefined);
    assert.equal(m.d_liq_long_24h, undefined);
    assert.equal(m.d_funding_pct, undefined);
    assert.equal(seen.length, 2, seen.join("\n"));
    assert.equal(m.d_ls_long_pct, 65);
    assert.equal(m.d_ls_long_pct_chg, 5);
  } finally {
    globalThis.fetch = original;
  }
});

test("derivative history requests wait until the CoinGlass candle scan is idle", async () => {
  const originalFetch = globalThis.fetch;
  const originalKey = process.env.NIHILIST_COINGLASS_API_KEY;
  let requests = 0;
  process.env.NIHILIST_COINGLASS_API_KEY = "test";
  globalThis.fetch = (async () => {
    requests += 1;
    return new Response(JSON.stringify({ code: "0", data: [] }), { status: 200 });
  }) as typeof fetch;
  setScanBusy(true);
  const lookup = derivativeMetrics("JCT-USDT", asOf);
  try {
    await new Promise((resolve) => setTimeout(resolve, 30));
    assert.equal(requests, 0, "derivative history must not compete with the active candle scan");
    setScanBusy(false);
    await lookup;
    assert.equal(requests, 2, "both history endpoints should run after the scan finishes");
  } finally {
    setScanBusy(false);
    await lookup.catch(() => {});
    globalThis.fetch = originalFetch;
    if (originalKey === undefined) delete process.env.NIHILIST_COINGLASS_API_KEY;
    else process.env.NIHILIST_COINGLASS_API_KEY = originalKey;
  }
});

test("BingX tickers map to CoinGlass bases", () => {
  assert.equal(cgBase("BTC-USDT"), "BTC");
  assert.equal(cgBase("USELES-USDT"), "USELESS");
});
