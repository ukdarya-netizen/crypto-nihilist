/**
 * Telegram delivery (as in BTC Bullet): every event of a LIVE trade is sent
 * to the channel (NIHILIST_TELEGRAM_CHANNEL, if set) and to every registered
 * user with access (approved, subscription active, signals on — see
 * lib/users.ts) whose signals were on before the event. One delivery row per recipient:
 * a success is never repeated when others fail; up to 8 attempts each.
 * Shadow trades (setup not in LIVE_SETUPS) never leave the dashboard.
 * Only signals and the daily/weekly/monthly reports go out: no service,
 * restart or API-outage messages.
 */
import { pool } from "@workspace/db";
import { logger } from "../lib/logger";
import { formatEvent, type EventForText, type SignalForText } from "./format";
import { notificationPhotoKind, shouldSuppressTelegramEvent } from "./notification-media";
import { startReports } from "./reports";
import { sendMessage, sendPhoto, signalChannel, telegramCall, telegramEnabled, TelegramError, type TelegramUpdate } from "./transport";
import { ensureUserTables, ownerEmail, recipientSql } from "../lib/users";
import { handleUpdate, setBotMenu } from "./bot";
import { MAX_AUTO_DELIVERY_AGE_MS, planEventDelivery, type DeliveryRecipient } from "./delivery-policy";

const MAX_ATTEMPTS = 8;
let delivering = false;

type QueueRow = SignalForText & EventForText & { event_id: number; signal_live: boolean; silent: boolean };

async function enqueue(): Promise<QueueRow[]> {
  const channel = signalChannel();
  const now = Date.now();
  const { rows } = await pool.query<QueueRow>(
    `SELECT e.id AS event_id, e.kind, e.price, e.detail, e.created_at, s.live AS signal_live,
            s.symbol, s.setup, s.htf, s.ltf, s.side, s.entry, s.stop, s.tp1, s.block_top, s.block_bottom,
            s.block_scope, s.opened_at, s.targets_source,
            (
              -- One message per candle: a progress alert in the same candle as
              -- break-even or TP1 repeats that message (+5% = break-even).
              -- Keep the milestone that also carries the trailing activation.
              (e.kind = 'milestone'
                AND NOT COALESCE((e.detail->>'trailingActivated')::boolean, false)
                AND EXISTS (
                SELECT 1 FROM nh_signal_events b
                WHERE b.signal_id = e.signal_id AND b.kind IN ('breakeven', 'tp1')
                  AND b.created_at = e.created_at))
              -- Trailing activation is included in the milestone alert.
              OR e.kind = 'trailing_on'
              -- One position per coin and side in Telegram: a signal opened while an
              -- earlier live one on the same coin/side was still open stays silent
              -- (duplicates opened before the one-per-coin rule; stats unchanged).
              OR EXISTS (
                SELECT 1 FROM nh_signals p
                WHERE p.live AND p.symbol = s.symbol AND p.side = s.side
                  AND (p.opened_at, p.id) < (s.opened_at, s.id)
                  AND (p.closed_at IS NULL OR p.closed_at > s.opened_at))
            ) AS silent
     FROM nh_signal_events e JOIN nh_signals s ON s.id = e.signal_id
     WHERE e.telegram_sent_at IS NULL AND e.telegram_attempts < $1
        AND (NOT s.live OR e.created_at >= $2)
        AND (NOT s.live OR $3::text IS NOT NULL OR EXISTS (
          SELECT 1 FROM nh_users u
          WHERE ${recipientSql("$4")} AND u.notify_since <= e.created_at
        ))
     ORDER BY e.id LIMIT 20`,
    [MAX_ATTEMPTS, new Date(now - MAX_AUTO_DELIVERY_AGE_MS), channel, ownerEmail()],
  );
  for (const row of rows) {
    if (!row.signal_live || row.silent) {
      await pool.query("UPDATE nh_signal_events SET telegram_sent_at = now() WHERE id = $1", [row.event_id]);
      continue;
    }
    const subs = await pool.query<{ chat_id: string }>(
      `SELECT u.chat_id FROM nh_users u WHERE ${recipientSql("$2")} AND u.notify_since <= $1`, [row.created_at, ownerEmail()],
    );
    const recipients: DeliveryRecipient[] = [
      ...(channel ? [{ chat: channel, isChannel: true }] : []),
      ...subs.rows.map((s) => ({ chat: s.chat_id, isChannel: false })),
    ];
    const plan = planEventDelivery({ signalLive: row.signal_live, createdAt: row.created_at }, recipients, now);
    if (plan.action !== "enqueue") continue;

    const text = formatEvent(row, row);
    for (const r of plan.recipients) {
      await pool.query(
        `INSERT INTO nh_telegram_deliveries (event_id, chat_id, channel, text) VALUES ($1, $2, $3, $4)
         ON CONFLICT (event_id, chat_id) DO NOTHING`,
        [row.event_id, r.chat, r.isChannel, text],
      );
    }
  }
  return rows.filter((r) => r.signal_live && !r.silent);
}

async function sendPending(): Promise<void> {
  const { rows } = await pool.query<{
    id: number; chat_id: string; channel: boolean; text: string; attempts: number;
    event_kind: string | null; event_reason: string | null;
  }>(
    `SELECT d.id, d.chat_id, d.channel, d.text, d.attempts,
            (SELECT e.kind FROM nh_signal_events e WHERE e.id = d.event_id) AS event_kind,
            (SELECT e.detail->>'reason' FROM nh_signal_events e WHERE e.id = d.event_id) AS event_reason
     FROM nh_telegram_deliveries d
     WHERE d.status = 'pending' AND d.next_attempt_at <= now() ORDER BY d.id LIMIT 20`,
  );
  for (const d of rows) {
    if (shouldSuppressTelegramEvent(d.event_kind)) {
      await pool.query("UPDATE nh_telegram_deliveries SET status = 'skipped', sent_at = now() WHERE id = $1", [d.id]);
      continue;
    }
    if (!d.channel) {
      const sub = await pool.query(`SELECT 1 FROM nh_users u WHERE u.chat_id = $1 AND ${recipientSql("$2")}`, [d.chat_id, ownerEmail()]);
      if (!sub.rowCount) {
        await pool.query("UPDATE nh_telegram_deliveries SET status = 'skipped' WHERE id = $1", [d.id]);
        continue;
      }
    }
    try {
      const photoKind = notificationPhotoKind(d.event_kind, d.event_reason);
      if (photoKind) await sendPhoto(d.chat_id, d.text, photoKind);
      else await sendMessage(d.chat_id, d.text);
      await pool.query("UPDATE nh_telegram_deliveries SET status = 'sent', sent_at = now() WHERE id = $1", [d.id]);
    } catch (err) {
      const attempts = d.attempts + 1;
      const blocked = !d.channel && err instanceof TelegramError && err.code === 403;
      // The user blocked the bot: signals off until /start.
      if (blocked) await pool.query("UPDATE nh_users SET notify = false, bot_blocked_at = now() WHERE chat_id = $1", [d.chat_id]);
      const waitMs = Math.max(3000 * 2 ** Math.min(attempts, 8), err instanceof TelegramError ? err.retryAfter * 1000 : 0);
      await pool.query(
        "UPDATE nh_telegram_deliveries SET attempts = $2, status = $3, next_attempt_at = $4 WHERE id = $1",
        [d.id, attempts, blocked ? "skipped" : attempts >= MAX_ATTEMPTS ? "failed" : "pending", new Date(Date.now() + waitMs)],
      );
      logger.warn({ err, deliveryId: d.id, attempts }, "nihilist: Telegram delivery failed");
    }
    await new Promise((r) => setTimeout(r, 100)); // below the bot-wide send limit
  }
}

async function settle(events: QueueRow[]): Promise<void> {
  for (const e of events) {
    const { rows } = await pool.query<{ status: string }>("SELECT status FROM nh_telegram_deliveries WHERE event_id = $1", [e.event_id]);
    if (!rows.length || rows.some((r) => r.status === "pending")) continue;
    if (rows.some((r) => r.status === "failed")) {
      await pool.query("UPDATE nh_signal_events SET telegram_attempts = $2 WHERE id = $1", [e.event_id, MAX_ATTEMPTS]);
    } else {
      await pool.query("UPDATE nh_signal_events SET telegram_sent_at = now() WHERE id = $1", [e.event_id]);
    }
  }
}

export async function deliverNext(): Promise<void> {
  if (delivering) return;
  delivering = true;
  try {
    await ensureUserTables();
    const events = await enqueue();
    await sendPending();
    await settle(events);
  } finally {
    delivering = false;
  }
}

// ---------------- bot updates (commands and buttons, see bot.ts) ----------------

let polling = false;

async function poll(): Promise<void> {
  await ensureUserTables();
  await setBotMenu();
  const state = await pool.query<{ next_update_id: string }>("SELECT next_update_id FROM nh_telegram_state WHERE key = 'updates'");
  let offset = Number(state.rows[0]?.next_update_id ?? 0);
  while (polling) {
    try {
      const updates = await telegramCall<TelegramUpdate[]>("getUpdates", {
        offset, timeout: 25, allowed_updates: ["message", "callback_query"],
      });
      for (const update of updates) {
        if (update.update_id < offset) continue;
        offset = update.update_id + 1;
        await pool.query(
          `INSERT INTO nh_telegram_state (key, next_update_id) VALUES ('updates', $1)
           ON CONFLICT (key) DO UPDATE SET next_update_id = EXCLUDED.next_update_id`,
          [offset],
        );
        await handleUpdate(update);
      }
    } catch (err) {
      if (err instanceof TelegramError && err.code === 409) {
        logger.error("nihilist: Telegram polling stopped — another poller or webhook uses this bot token");
        polling = false;
        return;
      }
      logger.warn({ err }, "nihilist: Telegram polling failed, retrying");
      await new Promise((r) => setTimeout(r, err instanceof TelegramError ? Math.max(5000, err.retryAfter * 1000) : 5000));
    }
  }
}

export function startTelegram(): void {
  if (!process.env.TELEGRAM_BOT_TOKEN) {
    logger.warn("nihilist: Telegram disabled — TELEGRAM_BOT_TOKEN not set");
    return;
  }
  if (!telegramEnabled()) {
    logger.warn("nihilist: Telegram off in the dev workspace — the published deployment sends (NIHILIST_TELEGRAM_IN_DEV=1 to force)");
    return;
  }
  if (!polling) {
    polling = true;
    void poll().catch((err) => { polling = false; logger.error({ err }, "nihilist: Telegram polling stopped"); });
  }
  startReports();
  setInterval(() => void deliverNext().catch((err) => logger.warn({ err }, "nihilist: Telegram delivery pass failed")), 3000).unref?.();
}
