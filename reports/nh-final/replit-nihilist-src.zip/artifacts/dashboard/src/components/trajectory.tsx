import { useEffect, useState } from "react";
import { compact, get, signed, tone, when } from "../lib/api";

type Point = { label: string; at: string; price: number | null; pct_from_entry: number | null; metrics: Record<string, number | string | null>; reconstructed: boolean };
const COLS: Array<[string, string, string?]> = [
  ["d_oi_chg1h", "OI 1ч", "%"], ["rsi_1h", "RSI 1ч"], ["btc_chg1h", "BTC 1ч", "%"],
];

/** The market at fixed points after entry and hourly after break-even. */
export function Trajectory({ id }: { id: number }) {
  const [points, setPoints] = useState<Point[] | null>(null);
  useEffect(() => {
    let alive = true;
    get<{ points: Point[] }>(`/nh/signals/${id}/trajectory`).then((d) => alive && setPoints(d.points)).catch(() => alive && setPoints([]));
    return () => { alive = false; };
  }, [id]);
  if (points === null) return <p className="text-muted">Загрузка…</p>;
  if (!points.length) return <p className="text-muted">Точки: касание блока и каждые 30 мин до сигнала; после входа — по текущему графику до закрытия; после БУ — каждый час до 72 часов, включая время после закрытия.</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px] font-mono text-[11px]">
        <thead><tr className="text-left text-muted">{["Точка", "Время", "Цена", "От входа", ...COLS.map((c) => c[1])].map((h) => <th key={h} className="pb-1 pr-3 font-normal">{h}</th>)}</tr></thead>
        <tbody>
          {points.map((p) => (
            <tr key={p.label} className="border-t border-border">
              <td className={`py-1 pr-3 ${p.label === "touch" || p.label.startsWith("-") ? "text-warn" : ""}`}>{p.label === "touch" ? "касание ОБ" : p.label}{p.reconstructed ? <span className="text-muted">*</span> : ""}</td>
              <td className="pr-3 text-muted">{when(p.at)}</td>
              <td className="pr-3">{p.price === null ? "—" : compact(p.price)}</td>
              <td className={`pr-3 ${tone(p.pct_from_entry)}`}>{signed(p.pct_from_entry, 2, "%")}</td>
              {COLS.map(([k, , suf]) => {
                const v = p.metrics?.[k];
                return <td key={k} className={`pr-3 ${typeof v === "number" && k !== "rsi_1h" ? tone(v) : ""}`}>{typeof v === "number" ? `${compact(v)}${suf ?? ""}` : "—"}</td>;
              })}
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-1 text-[10px] text-muted">Точки `be+1h` … `be+72h` отсчитываются от переноса стопа в безубыток и продолжаются после закрытия сделки.</p>
      <p className="mt-1 text-[10px] text-muted">* восстановлено позже по истории свечей и CoinGlass</p>
    </div>
  );
}
